import cv2

from ultralytics import YOLO
import supervision as sv
from supervision import process_video
import numpy as np
from cv2 import VideoWriter
from cv2 import VideoWriter_fourcc
from line_counter_modified import LineZoneAnnotator, LineZone
from supervision.draw.color import Color


# Ligne 1 (bonbons roses)
LINE_START_1 = sv.Point(320, 0)
LINE_END_1 = sv.Point(320, 480)

# Ligne 2 (bonbons verts)
LINE_START_2 = sv.Point(320, 0)
LINE_END_2 = sv.Point(320, 480)

# Ligne 4 (bonbons oranges)
LINE_START_4 = sv.Point(320, 0)
LINE_END_4 = sv.Point(320, 480)

# Ligne 5 (emballages vides)
LINE_START_5 = sv.Point(320, 0)
LINE_END_5 = sv.Point(320, 480)

# Ligne 6 (bonbons sans emballages)
LINE_START_6 = sv.Point(320, 0)
LINE_END_6 = sv.Point(320, 480)

# Ligne 7 (total)
#LINE_START_7 = sv.Point(320, 0)
#LINE_END_7 = sv.Point(320, 480)

############################################ Position des textes #####################################################

# Text annotations
# Ligne 1 (bonbons roses)
in_text_x_1 = 15
in_text_y_1 = 25

out_text_x_1 = 275
out_text_y_1 = 465

# Ligne 2 (bonbons verts)
in_text_x_2 = 15
in_text_y_2 = 95

out_text_x_2 = 275
out_text_y_2 = 465

# Ligne 4 (bonbons oranges)
in_text_x_4 = 15
in_text_y_4 = 60

out_text_x_4 = 275
out_text_y_4 = 465

# Ligne 5 (emballages vides)
in_text_x_5 = 15
in_text_y_5 = 465

out_text_x_5 = 275
out_text_y_5 = 465

# Ligne 6 (bonbons sans emballages)
in_text_x_6 = 15
in_text_y_6 = 440

out_text_x_6 = 275
out_text_y_6 = 465

# Ligne 7 (total)
#in_text_x_7 = 275
#in_text_y_7 = 25

#out_text_x_7 = 275
#out_text_y_7 = 50

############################################ Position des textes #####################################################

# Ligne 1
in_text_position_1 = (in_text_x_1, in_text_y_1)
out_text_position_1 = (out_text_x_1, out_text_y_1)

# Ligne 2
in_text_position_2 = (in_text_x_2, in_text_y_2)
out_text_position_2 = (out_text_x_2, out_text_y_2)

# Ligne 4
in_text_position_4 = (in_text_x_4, in_text_y_4)
out_text_position_4 = (out_text_x_4, out_text_y_4)

# Ligne 5
in_text_position_5 = (in_text_x_5, in_text_y_5)
out_text_position_5 = (out_text_x_5, out_text_y_5)

# Ligne 6
in_text_position_6 = (in_text_x_6, in_text_y_6)
out_text_position_6 = (out_text_x_6, out_text_y_6)

# Ligne 5
#in_text_position_7 = (in_text_x_7, in_text_y_7)
#out_text_position_7 = (out_text_x_7, out_text_y_7)

###################################################################################################################


def main():
    # LineZone : Counts the number of objects that cross a line


    line_counter_1 = LineZone(start=LINE_START_1, end=LINE_END_1)
    line_counter_2 = LineZone(start=LINE_START_2, end=LINE_END_2)
    line_counter_4 = LineZone(start=LINE_START_4, end=LINE_END_4)
    line_counter_5 = LineZone(start=LINE_START_5, end=LINE_END_5)
    line_counter_6 = LineZone(start=LINE_START_6, end=LINE_END_6)
    #line_counter_7 = LineZone(start=LINE_START_7, end=LINE_END_7)


    # LineZoneAnnotator : Initialize the LineCounterAnnotator object with default values (dessine les lignes de comptage et affiche les compteurs)
    line_annotator_1 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#ed174f"), text_thickness=1, text_scale=0.5, custom_in_text="in rose ", custom_out_text="out")

    line_annotator_2 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#78be20"), text_thickness=1, text_scale=0.5, custom_in_text="in vert ", custom_out_text="out")

    line_annotator_4 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#1481C1"), text_thickness=1, text_scale=0.5, custom_in_text="in orange ", custom_out_text="out")

    line_annotator_5 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#9b597c"), text_thickness=1, text_scale=0.5, custom_in_text="in papier ", custom_out_text="out")

    line_annotator_6 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#9b597c"), text_thickness=1, text_scale=0.5, custom_in_text="in sans emballage ", custom_out_text="out")

    #line_annotator_7 = LineZoneAnnotator(thickness=2, color=sv.Color.from_hex("#DDA8A2"), text_thickness=1, text_scale=0.5, custom_in_text="in Total ", custom_out_text="out Total ")


    # BoxAnnotator : A class for drawing bounding boxes on an image using detections provided
    box_annotator = sv.BoxAnnotator(
        thickness=2,
        text_thickness=1,
        text_scale=0.5
    )
    video = cv2.VideoWriter('yolov8_indiv.avi', VideoWriter_fourcc(*'MP42'), 25.0, (640, 480))
    # Load a model
    model = YOLO("/home/actemium/ultralytics/runs/detect/train_last/weights/best.pt") #modèle entraîné
    #model = YOLO("yolov8n.pt")

    for result in model.track(source=4, stream=True, show=True, save = True, half=True, agnostic_nms=True, tracker = "bytetrack.yaml"):
        
        frame = result.orig_img
        detections = sv.Detections.from_yolov8(result)

	# To prevent the scrpit from crashing when we have no detections 
        if result.boxes.id is not None:
            detections.tracker_id = result.boxes.id.cpu().numpy().astype(int)
        

	# Add labels to bounding boxes
        labels = [
            f"{tracker_id} {model.model.names[class_id]} {confidence:0.2f}"
            for _, confidence, class_id, tracker_id
            in detections
        ]

	# Annotate : Draws bounding boxes on the frame using the detections provided
        frame = box_annotator.annotate(
            scene=frame, 
            detections=detections,
            labels=labels
        )


       # Detecter les bonbons roses
        detections_1 = detections[detections.class_id==0]

        # Detecter les bonbons verts
        detections_2 = detections[detections.class_id==1]

        # Detecter les bonbons oranges
        detections_4 = detections[detections.class_id==3]

        # Detecter les emballages vides
        detections_5 = detections[detections.class_id==4]

        # Detecter les bonbons sans emballages
        detections_6 = detections[detections.class_id==5]


	    # trigger: updates the in_count and out_count for the detections that cross the line
        # Detecter les bonbons roses
        line_counter_1.trigger(detections=detections_1)

        # Detecter les bonbons verts
        line_counter_2.trigger(detections=detections_2)

        # Detecter les bonbons oranges
        line_counter_4.trigger(detections=detections_4)

        # Detecter les emballages vides
        line_counter_5.trigger(detections=detections_5)

        # Detecter les bonbons sans emballages
        line_counter_6.trigger(detections=detections_6)

        # Detecter tous les bonbons 
        #line_counter_7.trigger(detections=detections)


        line_annotator_1.annotate_modified(frame=frame, line_counter=line_counter_1, in_text_position =in_text_position_1, out_text_position= out_text_position_1)
        line_annotator_2.annotate_modified(frame=frame, line_counter=line_counter_2, in_text_position =in_text_position_2, out_text_position= out_text_position_2)
        line_annotator_4.annotate_modified(frame=frame, line_counter=line_counter_4, in_text_position =in_text_position_4, out_text_position= out_text_position_4)
        line_annotator_5.annotate_modified(frame=frame, line_counter=line_counter_5, in_text_position =in_text_position_5, out_text_position= out_text_position_5)
        line_annotator_6.annotate_modified(frame=frame, line_counter=line_counter_6, in_text_position =in_text_position_6, out_text_position= out_text_position_6)
        #line_annotator_7.annotate_modified(frame=frame, line_counter=line_counter_7, in_text_position =in_text_position_7, out_text_position= out_text_position_7)


        cv2.imshow("yolov8", frame)
        video.write(frame)
        if (cv2.waitKey(30) == 27):
            break


if __name__ == "__main__":
    main()
